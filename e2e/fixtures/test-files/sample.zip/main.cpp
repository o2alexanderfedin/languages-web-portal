#include <stdio.h>
int main() {
    printf("Hello from test\n");
    return 0;
}
